#!/bin/bash

echo "hello world"

echo "shasum -a 256 helloworld.sh"

echo "hello world"

echo "tar -czvf v0.0.2.tar.gz helloworld.sh"

echo "mv v0.0.2.tar.gz archive/"

echo "hello world"

echo "hello world"

echo "hello world"

echo "hello world"

echo "hello world"